const express = require("express");
const router = express.Router();
const db = require("../database");
const { verifyToken } = require("./auth");

// ============================
// CREAR PEDIDO (PÚBLICO)
// ============================
router.post("/", (req, res) => {
  const { nombre_cliente, items, total, forma_pago, pagado } = req.body;

  if (!nombre_cliente || !items || !items.length || total == null || !forma_pago) {
    return res.status(400).json({ error: "Datos incompletos del pedido" });
  }

  const items_json = JSON.stringify(items);
  const fecha_hora = new Date().toISOString();

  db.run(
    `
    INSERT INTO pedidos (nombre_cliente, items_json, total, forma_pago, pagado, fecha_hora)
    VALUES (?, ?, ?, ?, ?, ?)
    `,
    [nombre_cliente, items_json, total, forma_pago, pagado ? 1 : 0, fecha_hora],
    function (err) {
      if (err) {
        console.error("Error guardando pedido:", err);
        return res.status(500).json({ error: "No se pudo guardar el pedido" });
      }
      res.json({ ok: true, id: this.lastID });
    }
  );
});

// ============================
// LISTAR PEDIDOS (ADMIN)
// ============================
router.get("/", verifyToken, (req, res) => {
  db.all("SELECT * FROM pedidos ORDER BY id DESC", [], (err, rows) => {
    if (err) {
      console.error("Error obteniendo pedidos:", err);
      return res.status(500).json({ error: "Error obteniendo pedidos" });
    }
    res.json(rows);
  });
});

module.exports = router;

