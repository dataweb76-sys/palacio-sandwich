const express = require("express");
const router = express.Router();
const db = require("../database");

// ===============================
// CREAR PEDIDO A DOMICILIO
// ===============================
router.post("/", async (req, res) => {
  try {
    const {
      nombre,
      telefono,
      direccion,
      formaPago,
      envio,
      distanciaKm,
      totalFinal,
      carrito,
      comprobanteQR
    } = req.body;

    if (!nombre || !telefono || !direccion) {
      return res.status(400).json({ error: "Faltan datos obligatorios" });
    }

    const items_json = JSON.stringify(carrito || []);

    const sql = `
      INSERT INTO pedidos 
      (nombre_cliente, direccion, telefono, forma_pago, total, envio, distancia_km, items_json, pagado)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.run(sql, [
      nombre,
      direccion,
      telefono,
      formaPago,
      totalFinal,
      envio,
      distanciaKm,
      items_json,
      formaPago === "qr" ? 0 : 0
    ]);

    res.json({ ok: true });
  } catch (e) {
    console.error("Error guardando pedido delivery:", e);
    res.status(500).json({ error: "Error interno" });
  }
});

module.exports = router;
