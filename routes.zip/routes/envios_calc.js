// routes/envios_calc.js
const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

// SE USA FETCH NATIVO DE NODE 18+ (NO REQUIERE node-fetch)

// Coordenadas del local desde .env
const LOCAL_LAT = parseFloat(process.env.LOCAL_LAT);
const LOCAL_LON = parseFloat(process.env.LOCAL_LON);
const ORS_API_KEY = process.env.ORS_API_KEY;

// ===========================================================
// CARGAR CONFIG DE ENVÍOS (misma usada en /config)
// ===========================================================
async function getConfig() {
  const configPath = path.join(__dirname, "..", "database", "config.json");

  if (!fs.existsSync(configPath)) {
    return {
      envio_10: 300,
      envio_20: 500,
      envio_30: 700,
      envio_40: 1000,
      envio_gratis_desde: 12000
    };
  }

  const raw = fs.readFileSync(configPath);
  return JSON.parse(raw);
}

// ===========================================================
// CALCULAR DISTANCIA + COSTO
// ===========================================================
router.post("/", async (req, res) => {
  try {
    const { direccion, total } = req.body;

    if (!direccion || !total) {
      return res.status(400).json({ error: "Faltan datos" });
    }

    // 1) GEOCODIFICAR DIRECCIÓN
    const geo = await fetch(
      `https://api.openrouteservice.org/geocode/search?api_key=${ORS_API_KEY}&text=${encodeURIComponent(
        direccion
      )}`
    );

    const geoData = await geo.json();

    if (!geoData.features || !geoData.features.length) {
      return res.status(400).json({ error: "Dirección no encontrada" });
    }

    const [clienteLon, clienteLat] = geoData.features[0].geometry.coordinates;

    // 2) CALCULAR RUTA / DISTANCIA REAL
    const ruta = await fetch(
      "https://api.openrouteservice.org/v2/directions/driving-car/geojson",
      {
        method: "POST",
        headers: {
          Authorization: ORS_API_KEY,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          coordinates: [
            [LOCAL_LON, LOCAL_LAT],
            [clienteLon, clienteLat]
          ]
        })
      }
    );

    const rutaJson = await ruta.json();

    const distanciaMetros =
      rutaJson.features?.[0]?.properties?.segments?.[0]?.distance || 0;

    const distanciaKm = distanciaMetros / 1000;

    // 3) CONFIG/VALORES
    const config = await getConfig();

    // 4) CALCULAR ENVÍO
    let costoEnvio = 0;

    if (parseFloat(total) >= config.envio_gratis_desde) {
      costoEnvio = 0;
    } else if (distanciaKm <= 1) {
      costoEnvio = config.envio_10;
    } else if (distanciaKm <= 2) {
      costoEnvio = config.envio_20;
    } else if (distanciaKm <= 3) {
      costoEnvio = config.envio_30;
    } else {
      costoEnvio = config.envio_40;
    }

    // RESPUESTA FINAL
    res.json({
      distancia_km: distanciaKm.toFixed(2),
      costo_envio: costoEnvio,
      total_final: parseFloat(total) + costoEnvio
    });

  } catch (error) {
    console.error("Error calcular envío:", error);
    res.status(500).json({ error: "Error en cálculo de envío" });
  }
});

module.exports = router;
