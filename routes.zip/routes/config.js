// routes/config.js
const express = require("express");
const router = express.Router();
const db = require("../database");
const { verifyToken } = require("./auth");

// ===============================
// OBTENER TODA LA CONFIGURACIÓN
// ===============================
router.get("/", verifyToken, (req, res) => {
  db.all("SELECT clave, valor FROM config", (err, rows) => {
    if (err) return res.status(500).json({ error: "Error leyendo configuración" });

    const config = {};
    rows.forEach(r => {
      config[r.clave] = r.valor;
    });

    res.json(config);
  });
});

// ===============================
// ACTUALIZAR CONFIGURACIÓN
// ===============================
router.put("/", verifyToken, (req, res) => {
  const campos = req.body; // { envio_10: "500", envio_20: "700", ... }

  const claves = Object.keys(campos);
  if (!claves.length) {
    return res.status(400).json({ error: "No hay datos para actualizar" });
  }

  const stmt = db.prepare("UPDATE config SET valor=? WHERE clave=?");

  db.serialize(() => {
    claves.forEach(clave => {
      stmt.run(campos[clave], clave);
    });
  });

  stmt.finalize(err => {
    if (err) return res.status(500).json({ error: "Error guardando configuración" });
    res.json({ message: "Configuración actualizada" });
  });
});

module.exports = router;
