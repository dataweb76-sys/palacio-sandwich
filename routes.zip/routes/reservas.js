// routes/reservas.js
const express = require("express");
const router = express.Router();
const db = require("../database");
const { verifyToken } = require("./auth");

// ======================================================
// OBTENER TODAS LAS RESERVAS
// ======================================================
router.get("/", verifyToken, (req, res) => {
  db.all("SELECT * FROM reservas ORDER BY fecha_reserva ASC", (err, rows) => {
    if (err) return res.status(500).json({ error: "Error obteniendo reservas" });
    res.json(rows);
  });
});

// ======================================================
// CREAR NUEVA RESERVA (CLIENTE O ADMIN)
// ======================================================
router.post("/", (req, res) => {
  const { nombre, detalle, fecha_reserva } = req.body;

  if (!nombre || !detalle || !fecha_reserva) {
    return res.status(400).json({ error: "Faltan datos" });
  }

  db.run(
    `INSERT INTO reservas (nombre, detalle, fecha_reserva, estado) 
     VALUES (?, ?, ?, 'pendiente')`,
    [nombre, detalle, fecha_reserva],
    function (err) {
      if (err)
        return res.status(500).json({ error: "No se pudo guardar la reserva" });

      res.json({
        message: "Reserva creada correctamente",
        id: this.lastID,
      });
    }
  );
});

// ======================================================
// CONFIRMAR RESERVA (PAGADA / APROBADA POR ADMIN)
// ======================================================
router.put("/confirmar/:id", verifyToken, (req, res) => {
  db.run(
    `UPDATE reservas 
     SET estado='confirmado', fecha_confirmacion=CURRENT_TIMESTAMP
     WHERE id=?`,
    [req.params.id],
    function (err) {
      if (err)
        return res.status(500).json({ error: "No se pudo confirmar la reserva" });

      res.json({ message: "Reserva confirmada" });
    }
  );
});

// ======================================================
// ELIMINAR RESERVA
// ======================================================
router.delete("/:id", verifyToken, (req, res) => {
  db.run(`DELETE FROM reservas WHERE id=?`, [req.params.id], function (err) {
    if (err)
      return res.status(500).json({ error: "No se pudo eliminar la reserva" });

    res.json({ message: "Reserva eliminada" });
  });
});

module.exports = router;
