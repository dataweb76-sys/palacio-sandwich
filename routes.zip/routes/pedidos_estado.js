// C:\El palacio del sándwich\server\routes\pedidos_estado.js
const express = require("express");
const router = express.Router();
const db = require("../database");
const { verifyToken } = require("./auth");

// Cambiar estado: pendiente → preparando
router.post("/preparando/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado = 'preparando' WHERE id=?", [id], () => {
    res.json({ ok: true });
  });
});

// Pedido listo
router.post("/listo/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado = 'listo' WHERE id=?", [id], () => {
    res.json({ ok: true, show_final: true });
  });
});

// Pedido entregado
router.post("/entregado/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado = 'entregado' WHERE id=?", [id], () => {
    res.json({ ok: true });
  });
});

// Filtrar por estado
router.get("/:estado", verifyToken, (req, res) => {
  const estado = req.params.estado;
  db.all("SELECT * FROM pedidos WHERE estado=?", [estado], (err, rows) => {
    res.json(rows);
  });
});
// pendiente -> preparando
router.post("/preparando/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado='preparando' WHERE id=?", [id], (err) => {
    if (err) return res.status(500).json({ error: "Error" });
    res.json({ ok: true });
  });
});

// preparando -> listo
router.post("/listo/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado='listo' WHERE id=?", [id], (err) => {
    if (err) return res.status(500).json({ error: "Error" });
    res.json({ ok: true });
  });
});

// listo -> entregado
router.post("/entregado/:id", verifyToken, (req, res) => {
  const id = req.params.id;
  db.run("UPDATE pedidos SET estado='entregado' WHERE id=?", [id], (err) => {
    if (err) return res.status(500).json({ error: "Error" });
    res.json({ ok: true });
  });
});

// listar por estado (para TV, etc.)
router.get("/:estado", (req, res) => {
  const estado = req.params.estado;
  db.all("SELECT * FROM pedidos WHERE estado=?", [estado], (err, rows) => {
    if (err) return res.status(500).json({ error: "Error" });
    res.json(rows);
  });
});
module.exports = router;
