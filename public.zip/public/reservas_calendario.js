const token = localStorage.getItem("token");
if (!token) location.href = "login.html";

let reservas = [];
let current = new Date();

async function cargarReservas() {
  const r = await fetch("/reservas", {
    headers: { Authorization: "Bearer " + token }
  });
  reservas = await r.json();
  renderCalendar();
}

function renderCalendar() {
  const year = current.getFullYear();
  const month = current.getMonth();

  document.getElementById("calTitulo").textContent =
    current.toLocaleDateString("es-AR", { month: "long", year: "numeric" });

  const grid = document.getElementById("calGrid");
  grid.innerHTML = "";

  const diasSemana = ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"];
  diasSemana.forEach(d => {
    const div = document.createElement("div");
    div.textContent = d;
    div.className = "cal-day-name";
    grid.appendChild(div);
  });

  const primerDia = new Date(year, month, 1);
  let inicio = primerDia.getDay();
  if (inicio === 0) inicio = 7;

  for (let i=1;i<inicio;i++) {
    const empty = document.createElement("div");
    grid.appendChild(empty);
  }

  const totalDias = new Date(year, month+1, 0).getDate();

  for (let dia = 1; dia <= totalDias; dia++) {
    const fecha = `${year}-${String(month+1).padStart(2,"0")}-${String(dia).padStart(2,"0")}`;

    const resDelDia = reservas.filter(r => r.fecha_reserva === fecha);

    const div = document.createElement("div");
    div.className = "cal-day";
    div.innerHTML = `<div class="num">${dia}</div>`;

    if (resDelDia.length > 0) {
      const badge = document.createElement("div");
      badge.className = "badge-res";
      badge.textContent = resDelDia.length;
      div.appendChild(badge);
    }

    div.onclick = () => mostrarReservasDelDia(fecha);
    grid.appendChild(div);
  }
}

function mostrarReservasDelDia(fecha) {
  const cont = document.getElementById("reservasDia");
  cont.innerHTML = "";

  const lista = reservas.filter(r => r.fecha_reserva === fecha);

  if (lista.length === 0) {
    cont.innerHTML = "<p>No hay reservas para este día</p>";
    return;
  }

  lista.forEach(r => {
    const div = document.createElement("div");
    div.className = "res-item " + (r.pagada ? "res-pagada" : "res-pendiente");
    div.innerHTML = `
      <strong>${r.nombre}</strong> (${r.hora_reserva || "-"})<br>
      Tel: ${r.telefono || "-"}<br>
      Dirección: ${r.direccion || "-"}<br>
      ${r.detalle}
    `;
    cont.appendChild(div);
  });
}

function prevMonth() {
  current.setMonth(current.getMonth() - 1);
  renderCalendar();
}

function nextMonth() {
  current.setMonth(current.getMonth() + 1);
  renderCalendar();
}

cargarReservas();
