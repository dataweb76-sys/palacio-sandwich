// ========================
// VALIDAR LOGIN
// ========================
const token = localStorage.getItem("token");
if (!token) location.href = "login.html";

// ========================
// CARGAR RESERVAS
// ========================
async function cargarReservas() {
  const res = await fetch("/reservas", {
    headers: { Authorization: "Bearer " + token }
  });
  const data = await res.json();

  const tbody = document.querySelector("#tablaReservas tbody");
  tbody.innerHTML = "";

  data.forEach(r => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${r.id}</td>
      <td>${r.nombre}</td>
      <td>${r.detalle}</td>
      <td>${formatearFecha(r.fecha_reserva)}</td>
      <td>${formatearFecha(r.creado)}</td>

      <td>
        <span class="${r.estado === "pendiente" ? "estado-pend" : "estado-ok"}">
          ${r.estado}
        </span>
      </td>

      <td>
        ${
          r.estado === "pendiente"
            ? `<button class="btn-ok" onclick="confirmar(${r.id})">✔ Confirmar</button>`
            : `<button class="btn-ya" disabled>✔ Confirmado</button>`
        }
        <button class="btn-del" onclick="eliminar(${r.id})">🗑 Eliminar</button>
      </td>
    `;

    tbody.appendChild(tr);
  });

  verificarAlarmas(data);
}

// ========================
// FORMATEAR FECHAS
// ========================
function formatearFecha(f) {
  if (!f) return "-";
  return new Date(f).toLocaleString("es-AR");
}

// ========================
// CONFIRMAR / MARCAR PAGADO
// ========================
async function confirmar(id) {
  if (!confirm("¿Confirmar esta reserva?")) return;

  const res = await fetch(`/reservas/confirmar/${id}`, {
    method: "PUT",
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json"
    }
  });

  if (res.ok) cargarReservas();
  else alert("Error al confirmar reserva");
}

// ========================
// ELIMINAR RESERVA
// ========================
async function eliminar(id) {
  if (!confirm("¿Eliminar esta reserva?")) return;

  await fetch(`/reservas/${id}`, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token }
  });

  cargarReservas();
}

// ========================
// BUSCADOR
// ========================
function filtrar() {
  const valor = document.getElementById("buscador").value.toLowerCase();
  const filas = document.querySelectorAll("#tablaReservas tbody tr");

  filas.forEach(f => {
    const nombre = f.children[1].textContent.toLowerCase();
    f.style.display = nombre.includes(valor) ? "" : "none";
  });
}

// ========================
// ALARMA UN DÍA ANTES
// ========================
function verificarAlarmas(reservas) {
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  reservas.forEach(r => {
    const fechaReserva = new Date(r.fecha_reserva);
    fechaReserva.setHours(0, 0, 0, 0);

    const diffDias = (fechaReserva - hoy) / 86400000;

    // Si falta exactamente 1 día
    if (diffDias === 1 && r.estado === "pendiente") {
      mostrarAlertaReserva(r);
    }
  });
}

// ========================
// MOSTRAR ALERTA
// ========================
function mostrarAlertaReserva(r) {
  const mensaje = `
⚠ RECORDATORIO DE RESERVA ⚠

Cliente: ${r.nombre}
Fecha: ${formatearFecha(r.fecha_reserva)}
Detalle: ${r.detalle}

Preparar el pedido con anticipación.
  `;

  console.log(mensaje);

  // Sonido de aviso (poné tu audio)
  const sonido = new Audio("sonidos/nuevo_pedido.mp3");
  sonido.play();

  // Popup nativo del navegador
  alert(mensaje);
}

// ========================
// INICIO
// ========================
document.addEventListener("DOMContentLoaded", cargarReservas);
