const token = localStorage.getItem("token");
if (!token) window.location.href = "login.html";

function goBack() {
  window.location.href = "admin.html";
}

function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

// ===============================
// CARGAR CONFIGURACIÓN ACTUAL
// ===============================
async function cargarConfig() {
  const res = await fetch("/config", {
    headers: { Authorization: "Bearer " + token }
  });

  const data = await res.json();

  document.getElementById("envio_10").value = data.envio_10 || 0;
  document.getElementById("envio_20").value = data.envio_20 || 0;
  document.getElementById("envio_30").value = data.envio_30 || 0;
  document.getElementById("envio_40").value = data.envio_40 || 0;
  document.getElementById("envio_gratis_desde").value = data.envio_gratis_desde || 0;
}

// ===============================
// GUARDAR CONFIGURACIÓN
// ===============================
async function guardarEnvios() {
  const msg = document.getElementById("msg");
  msg.className = "mensaje";
  msg.style.display = "none";

  const body = {
    envio_10: document.getElementById("envio_10").value,
    envio_20: document.getElementById("envio_20").value,
    envio_30: document.getElementById("envio_30").value,
    envio_40: document.getElementById("envio_40").value,
    envio_gratis_desde: document.getElementById("envio_gratis_desde").value
  };

  const res = await fetch("/config", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    body: JSON.stringify(body)
  });

  if (res.ok) {
    msg.textContent = "Configuración guardada correctamente";
    msg.className = "mensaje ok";
  } else {
    msg.textContent = "Error guardando la configuración";
    msg.className = "mensaje error";
  }
}

document.addEventListener("DOMContentLoaded", cargarConfig);
