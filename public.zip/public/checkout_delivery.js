// =========================
// TOMAR CARRITO
// =========================
let carrito = JSON.parse(localStorage.getItem("cart") || "[]");

if (!carrito.length) {
  window.location.href = "index.html";
}

let costoEnvio = 0;
let distanciaKm = 0;

// =========================
// ACTUALIZA TOTALES VISUAL
// =========================
function actualizarTotal() {
  let subtotal = carrito.reduce(
    (acc, i) => acc + i.precio * i.cantidad,
    0
  );

  let total = subtotal + costoEnvio;

  document.getElementById("costoEnvio").innerText = `$${costoEnvio}`;
  document.getElementById("totalFinal").innerText = `$${total}`;
  document.getElementById("distanciaKm").innerText = `${distanciaKm} km`;

  return { subtotal, total };
}

// =========================
// CALCULAR ENVÍO
// =========================
async function calcularEnvio() {
  const direccion = document.getElementById("direccion").value.trim();
  if (direccion.length < 3) return;

  try {
    const res = await fetch("/api/calcular-envio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ direccion })
    });

    const data = await res.json();

    costoEnvio = Number(data.envio || 0);
    distanciaKm = Number(data.distancia_km || 0).toFixed(1);

    actualizarTotal();
  } catch (err) {
    console.error("Error calculando envío:", err);
  }
}

document.getElementById("direccion").addEventListener("input", calcularEnvio);

// =========================
// CAMBIAR MÉTODO PAGO
// =========================
document.getElementById("formaPago").addEventListener("change", () => {
  const pago = document.getElementById("formaPago").value;
  document.getElementById("qrSection").style.display =
    pago === "qr" ? "block" : "none";
});

// =========================
// FINALIZAR DELIVERY
// =========================
async function finalizarDelivery() {
  const nombre = document.getElementById("nombre").value.trim();
  const telefono = document.getElementById("telefono").value.trim();
  const direccion = document.getElementById("direccion").value.trim();
  const formaPago = document.getElementById("formaPago").value;

  if (!nombre || !telefono || !direccion) {
    alert("Completá todos los datos.");
    return;
  }

  const { total } = actualizarTotal();

  let comprobanteQR = null;

  if (formaPago === "qr") {
    const file = document.getElementById("fileQR").files[0];
    if (file) {
      const reader = new FileReader();
      comprobanteQR = await new Promise((resolve) => {
        reader.onload = () => resolve(reader.result);
        reader.readAsDataURL(file);
      });
    }
  }

  try {
    const res = await fetch("/pedidos_delivery", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nombre,
        telefono,
        direccion,
        formaPago,
        envio: costoEnvio,
        distanciaKm,
        totalFinal: total,
        carrito,
        comprobanteQR
      })
    });

    const data = await res.json();

    if (!data.ok) {
      alert("No se pudo guardar el pedido.");
      return;
    }
  } catch (err) {
    console.error("Error backend:", err);
    alert("Error enviando el pedido.");
    return;
  }

  localStorage.removeItem("cart");
  localStorage.removeItem("tipoPedido");

  document.getElementById("msgConfirm").innerHTML =
    `Gracias ${nombre}.<br>Tu pedido está en camino.<br><br><strong>Total:</strong> $${total}`;

  document.getElementById("popupConfirm").style.display = "flex";
}

