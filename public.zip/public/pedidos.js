// ========================================
// routes/pedidos.js (VERSIÓN UNIFICADA)
// ========================================
const express = require("express");
const router = express.Router();
const db = require("../database");
const { verifyToken } = require("./auth");

// ========================================
// CREAR PEDIDO — RETIRO EN LOCAL
// ========================================
router.post("/local", (req, res) => {
  const { nombre, telefono, horaEntrega, carrito, total, formaPago } = req.body;

  if (!nombre || !carrito || !carrito.length || !total) {
    return res.status(400).json({ error: "Faltan datos del pedido." });
  }

  const items_json = JSON.stringify(carrito);
  const fecha_hora = new Date().toISOString();

  const sql = `
    INSERT INTO pedidos 
    (nombre_cliente, telefono, hora_entrega, forma_pago, total, items_json, tipo, pagado, estado, fecha_hora)
    VALUES (?, ?, ?, ?, ?, ?, 'local', ?, 'pendiente', ?)
  `;

  db.run(sql, [
    nombre,
    telefono || "",
    horaEntrega || "",
    formaPago || "efectivo",
    total,
    items_json,
    formaPago === "qr" ? 0 : 0,
    fecha_hora
  ],
  function (err) {
    if (err) {
      console.error("❌ Error creando pedido local:", err);
      return res.status(500).json({ error: "Error interno." });
    }

    res.json({ ok: true, id: this.lastID });
  });
});

// ========================================
// CREAR PEDIDO — DELIVERY
// ========================================
router.post("/delivery", (req, res) => {
  const {
    nombre,
    telefono,
    direccion,
    formaPago,
    envio,
    distanciaKm,
    totalFinal,
    carrito,
    comprobanteQR,
    horaEntrega
  } = req.body;

  if (!nombre || !telefono || !direccion || !carrito || !carrito.length) {
    return res.status(400).json({ error: "Datos incompletos para delivery" });
  }

  const items_json = JSON.stringify(carrito);
  const fecha_hora = new Date().toISOString();

  const sql = `
    INSERT INTO pedidos
    (nombre_cliente, telefono, direccion, forma_pago, total, envio, distancia_km, items_json, tipo, pagado, estado, comprobanteQR, hora_entrega, fecha_hora)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'delivery', ?, 'pendiente', ?, ?, ?)
  `;

  db.run(sql, [
    nombre,
    telefono,
    direccion,
    formaPago,
    totalFinal,
    envio,
    distanciaKm,
    items_json,
    formaPago === "qr" ? 0 : 0,
    comprobanteQR || null,
    horaEntrega || "",
    fecha_hora
  ],
  function (err) {
    if (err) {
      console.error("❌ Error guardando pedido delivery:", err);
      return res.status(500).json({ error: "Error interno." });
    }

    res.json({ ok: true, id: this.lastID });
  });
});

// ========================================
// LISTAR PEDIDOS (ADMIN)
// ========================================
router.get("/", verifyToken, (req, res) => {
  db.all("SELECT * FROM pedidos ORDER BY id DESC", [], (err, rows) => {
    if (err) {
      console.error("❌ Error obteniendo pedidos:", err);
      return res.status(500).json({ error: "Error interno" });
    }
    res.json(rows);
  });
});

module.exports = router;
