// =======================
// VALIDAR LOGIN
// =======================
const token = localStorage.getItem("token");
if (!token) window.location.href = "login.html";

function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

// =======================
// NAVEGACIÓN
// =======================
function irProductos() { window.location.href = "productos.html"; }
function irPromos() { window.location.href = "promociones.html"; }
function irCategorias() { window.location.href = "categorias.html"; }
function irPedidos() { window.location.href = "pedidos.html"; }
function irStock() { window.location.href = "stock.html"; }
function irEnvios() { window.location.href = "envios.html"; }
function irAdmins() { window.location.href = "admin-config.html"; }

// =======================
// PRODUCTOS
// =======================
async function cargarProductos() {
  try {
    const res = await fetch("/products");
    const productos = await res.json();

    document.getElementById("stat-productos").textContent = productos.length;

    let ultimo = "-";
    let stockBajo = 0;

    if (productos.length) {
      const ordenados = [...productos].sort((a, b) => b.id - a.id);
      ultimo = ordenados[0].name;

      stockBajo = productos.filter((p) => {
        if (p.stock == null) return false;
        if (p.stock === 0) return true;
        return p.stock <= (p.stock_alert || 2);
      }).length;
    }

    document.getElementById("stat-ultimo").textContent = ultimo;
    document.getElementById("stat-stock-bajo").textContent = stockBajo;

  } catch (e) {
    console.error("Error cargando productos:", e);
  }
}

// =======================
// PROMOS
// =======================
async function cargarPromos() {
  try {
    const res = await fetch("/promos");
    const promos = await res.json();

    document.getElementById("stat-promos").textContent = promos.length;

  } catch (e) {
    console.error("Error cargando promos:", e);
  }
}

// =======================
// PEDIDOS PENDIENTES
// =======================
async function cargarPedidosPendientes() {
  try {
    const res = await fetch("/pedidos", {
      headers: { Authorization: "Bearer " + token }
    });

    if (res.status === 401) {
      alert("Sesión expirada");
      logout();
      return;
    }

    const pedidos = await res.json();
    const pendientes = pedidos.filter((p) => p.pagado == 0).length;

    document.getElementById("stat-pendientes").textContent = pendientes;

  } catch (e) {
    console.error("Error cargando pedidos pendientes:", e);
  }
}

// =======================
// RESERVAS PENDIENTES
// =======================
async function verificarReservas() {
  try {
    const res = await fetch("/reservas", {
      headers: { Authorization: "Bearer " + token }
    });

    const data = await res.json();
    const pendientes = data.filter((r) => r.estado === "pendiente").length;

    document.getElementById("badgeReservas").textContent = pendientes;

    if (pendientes > 0) {
      new Audio("sonidos/nuevo_pedido.mp3").play();
    }
  } catch (e) {
    console.error("Error verificando reservas:", e);
  }
}

setInterval(verificarReservas, 15000);
verificarReservas();

// =======================
// INICIO
// =======================
window.addEventListener("DOMContentLoaded", () => {
  cargarProductos();
  cargarPromos();
  cargarPedidosPendientes();

  setInterval(cargarPedidosPendientes, 10000);
});
