/* =======================================================
   VARIABLES GLOBALES
======================================================= */
let carrito = JSON.parse(localStorage.getItem("cart") || "[]");
let categoriasCliente = [];
let heroIndex = 0;

const heroImages = [
  "bannerpalacios.jpg",
  "arabitos.png",
  "pizza.png",
  "sandmiga.png",
  "home-masamadre-mobile-compress1.png",
];

/* =======================================================
   HERO / CARRUSEL
======================================================= */
function setHeroImage() {
  const hero = document.getElementById("hero");
  if (!hero) return;

  hero.style.backgroundImage = `url('${heroImages[heroIndex]}')`;

  const dots = document.getElementById("hero-dots");
  if (!dots) return;

  dots.innerHTML = "";

  heroImages.forEach((_, idx) => {
    const d = document.createElement("button");
    d.className = "hero-dot" + (idx === heroIndex ? " active" : "");
    d.onclick = () => {
      heroIndex = idx;
      setHeroImage();
    };
    dots.appendChild(d);
  });
}

function nextHero() {
  heroIndex = (heroIndex + 1) % heroImages.length;
  setHeroImage();
}

/* =======================================================
   MENÚ LATERAL
======================================================= */
function openMenu() {
  document.getElementById("sideMenu").classList.add("open");
}
function closeMenu() {
  document.getElementById("sideMenu").classList.remove("open");
}

window.openMenu = openMenu;
window.closeMenu = closeMenu;

/* =======================================================
   BOTONES HERO
======================================================= */
function pedirRetirar() {
  localStorage.setItem("tipoPedido", "retiroLocal");
  abrirPopupCategorias();
}

function irDelivery() {
  localStorage.setItem("tipoPedido", "delivery");
  abrirPopupCategorias();
}

function irReservas() {
  alert("La página de reservas estará disponible próximamente 🙂");
}

window.pedirRetirar = pedirRetirar;
window.irDelivery = irDelivery;
window.irReservas = irReservas;

/* =======================================================
   CATEGORÍAS (CLIENTE)
======================================================= */
async function cargarCategoriasCliente() {
  try {
    const res = await fetch("/categories");
    const data = await res.json();

    categoriasCliente = data
      .filter((c) => c.tipo === "cliente" && c.visible !== 0)
      .sort((a, b) => (a.orden || 0) - (b.orden || 0));

    renderPopupCategorias();
  } catch (err) {
    console.error("Error cargando categorías:", err);
  }
}

function renderPopupCategorias() {
  const cont = document.getElementById("popupCategoriasLista");
  if (!cont) return;

  cont.innerHTML = "";

  categoriasCliente.forEach((cat) => {
    const div = document.createElement("div");
    div.className = "categoria-popup-card";
    div.onclick = () => abrirPopupProductos(cat);

    div.innerHTML = `
      <img src="${cat.image || "logo_palacio.jpg"}" alt="${cat.nombre}">
      <span>${cat.nombre}</span>
    `;

    cont.appendChild(div);
  });
}

function abrirPopupCategorias() {
  const pop = document.getElementById("popupCategorias");
  if (pop) pop.style.display = "flex";
}

function cerrarPopupCategorias() {
  const pop = document.getElementById("popupCategorias");
  if (pop) pop.style.display = "none";
}

window.abrirPopupCategorias = abrirPopupCategorias;
window.cerrarPopupCategorias = cerrarPopupCategorias;

/* =======================================================
   PRODUCTOS POR CATEGORÍA
======================================================= */
async function abrirPopupProductos(cat) {
  cerrarPopupCategorias();

  const titulo = document.getElementById("popupProductosTitulo");
  const lista = document.getElementById("popupProductosLista");
  const pop = document.getElementById("popupProductos");

  if (!lista || !pop) return;

  if (titulo) titulo.textContent = cat.nombre;
  lista.innerHTML = "Cargando…";
  pop.style.display = "flex";

  try {
    const res = await fetch(`/products?categoria=${encodeURIComponent(cat.nombre)}`);
    const productos = await res.json();
    renderPopupProductos(productos);
  } catch (err) {
    console.error("Error cargando productos:", err);
    lista.innerHTML = "<p>Error cargando productos.</p>";
  }
}

function renderPopupProductos(lista) {
  const cont = document.getElementById("popupProductosLista");
  if (!cont) return;

  cont.innerHTML = "";

  if (!lista.length) {
    cont.innerHTML = "<p>No hay productos en esta categoría.</p>";
    return;
  }

  lista.forEach((p) => {
    const div = document.createElement("div");
    div.className = "producto-popup-card";

    const nombreEscapado = p.name.replace(/'/g, "\\'");

    div.innerHTML = `
      <img src="${p.image || "logo_palacio.jpg"}" alt="${p.name}">
      <div class="producto-info">
        <div class="producto-nombre">${p.name}</div>
        <div class="producto-descripcion">${p.description || ""}</div>
        <div class="producto-precio">$${p.price}</div>
        <button class="btn-agregar"
          onclick="agregarAlCarrito(${p.id}, '${nombreEscapado}', ${p.price})">
          Agregar
        </button>
      </div>
    `;

    cont.appendChild(div);
  });
}

function volverACategorias() {
  cerrarPopupProductos();
  abrirPopupCategorias();
}

function cerrarPopupProductos() {
  const pop = document.getElementById("popupProductos");
  if (pop) pop.style.display = "none";
}

window.volverACategorias = volverACategorias;
window.cerrarPopupProductos = cerrarPopupProductos;

/* =======================================================
   CARRITO (POPUP LATERAL)
======================================================= */
function abrirPopupCarrito() {
  const pop = document.getElementById("popupCarrito");
  if (!pop) return;

  pop.classList.add("abierto");
  renderPopupCarrito();
}

function cerrarPopupCarrito() {
  const pop = document.getElementById("popupCarrito");
  if (!pop) return;
  pop.classList.remove("abierto");
}

window.abrirPopupCarrito = abrirPopupCarrito;
window.cerrarPopupCarrito = cerrarPopupCarrito;

function agregarAlCarrito(id, nombre, precio) {
  const item = carrito.find((i) => i.id === id);
  if (item) item.cantidad++;
  else carrito.push({ id, nombre, precio, cantidad: 1 });

  localStorage.setItem("cart", JSON.stringify(carrito));
  abrirPopupCarrito();
}

window.agregarAlCarrito = agregarAlCarrito;

function renderPopupCarrito() {
  const cont = document.getElementById("popupCarritoItems");
  const totalEl = document.getElementById("popupCarritoTotal");
  if (!cont || !totalEl) return;

  cont.innerHTML = "";
  let total = 0;

  if (!carrito.length) {
    cont.innerHTML = "<p>Tu carrito está vacío.</p>";
    totalEl.textContent = "0";
    return;
  }

  carrito.forEach((p) => {
    const sub = (p.precio || 0) * (p.cantidad || 1);
    total += sub;

    const div = document.createElement("div");
    div.className = "cart-item";

    div.innerHTML = `
      <span>${p.cantidad}× ${p.nombre}</span>
      <span>$${sub}</span>
    `;

    cont.appendChild(div);
  });

  totalEl.textContent = total;
}

/* =======================================================
   FINALIZAR PEDIDO
======================================================= */
function finalizarPedidoDesdeCarrito() {
  if (!carrito.length) {
    alert("El carrito está vacío.");
    return;
  }

  const tipo = localStorage.getItem("tipoPedido");

  if (tipo === "delivery") {
    // Dejamos el carrito en localStorage para que lo use checkout_delivery
    window.location.href = "checkout_delivery.html";
    return;
  }

  if (tipo === "retiroLocal") {
    // Más adelante: popup con nombre / teléfono / hora y envío a pedidos.html
    alert("Retiro en local: después armamos el formulario con nombre, teléfono y hora 🙂");
    return;
  }

  alert("Primero elegí si es para Retirar o Delivery.");
}

window.finalizarPedidoDesdeCarrito = finalizarPedidoDesdeCarrito;

/* =======================================================
   PROMOS (CLIENTE)
======================================================= */
async function cargarPromosCliente() {
  const cont = document.getElementById("promo-lista");
  if (!cont) return;

  try {
    const res = await fetch("/promos");
    const data = await res.json();

    cont.innerHTML = "";

    if (!data.length) {
      cont.innerHTML = "<p>Por ahora no hay promociones activas.</p>";
      return;
    }

    data.forEach((p) => {
      const div = document.createElement("div");
      div.className = "promo-card";

      div.innerHTML = `
        ${p.image ? `<img src="${p.image}" alt="${p.title}">` : ""}
        <h3>${p.title}</h3>
        <p>${p.description || ""}</p>
        ${p.price ? `<strong>$${p.price}</strong>` : ""}
      `;

      cont.appendChild(div);
    });
  } catch (err) {
    console.error("Error cargando promos:", err);
    cont.innerHTML = "<p>Error cargando promociones.</p>";
  }
}

/* =======================================================
   CARRUSEL FOTOS LOCAL
======================================================= */
let carruselIndex = 0;

function cambiarFotoDerecha() {
  const fotos = document.querySelectorAll(".foto-carrusel");
  if (!fotos.length) return;

  fotos.forEach((f) => f.classList.remove("active"));
  carruselIndex = (carruselIndex + 1) % fotos.length;
  fotos[carruselIndex].classList.add("active");
}

/* =======================================================
   INICIO
======================================================= */
window.addEventListener("DOMContentLoaded", () => {
  setHeroImage();
  setInterval(nextHero, 6000);

  cargarCategoriasCliente();
  cargarPromosCliente();

  cambiarFotoDerecha();
  setInterval(cambiarFotoDerecha, 5000);

  const year = document.getElementById("anio");
  if (year) year.textContent = new Date().getFullYear();
});
