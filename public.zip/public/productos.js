// ========================
// VALIDAR LOGIN
// ========================
const token = localStorage.getItem("token");
if (!token) window.location.href = "login.html";

function goBack() {
  window.location.href = "admin.html";
}

function logout() {
  localStorage.removeItem("token");
  window.location.href = "login.html";
}

// ========================
// CARGAR CATEGORÍAS SOLO TIPO PRODUCTO
// ========================
async function cargarCategoriasDisponible() {
  try {
    const res = await fetch("/categories");
    const data = await res.json();

    const cont = document.getElementById("catButtonsContainer");
    cont.innerHTML = "";

    data
      .filter((c) => c.tipo === "producto")
      .forEach((cat) => {
        const b = document.createElement("span");
        b.className = "cat-btn";
        b.dataset.value = cat.nombre;
        b.textContent = cat.nombre;
        cont.appendChild(b);
      });

    setupCategoryButtons();
  } catch (e) {
    console.error("Error cargando categorías", e);
  }
}

// ========================
// BOTONES DE CATEGORIA
// ========================
function setupCategoryButtons() {
  const buttons = document.querySelectorAll(".cat-btn");
  const input = document.getElementById("prod_category");

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      buttons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      input.value = btn.dataset.value;
    });
  });
}

function marcarCategoriaActiva(nombre) {
  const buttons = document.querySelectorAll(".cat-btn");
  const input = document.getElementById("prod_category");
  input.value = nombre;

  buttons.forEach((b) => {
    if (b.dataset.value.toLowerCase() === (nombre || "").toLowerCase()) {
      b.classList.add("active");
    } else {
      b.classList.remove("active");
    }
  });
}

// ========================
// CARGAR PRODUCTOS
// ========================
async function cargarProductos() {
  const res = await fetch("/products");
  const data = await res.json();

  const tbody = document.querySelector("#tablaProductos tbody");
  tbody.innerHTML = "";

  data.forEach((p) => {
    const tr = document.createElement("tr");

    tr.className =
      p.stock <= 0
        ? "sin-stock"
        : p.stock <= p.stock_alert
        ? "stock-bajo"
        : "";

    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${p.image ? `<img src="${p.image}" width="60">` : ""}</td>
      <td>${p.name}</td>
      <td>${p.category || "-"}</td>
      <td>$${p.price}</td>
      <td>${p.stock}</td>
      <td>${p.description || ""}</td>
      <td>
        <button onclick="editarProducto(${p.id})">Editar</button>
        <button class="eliminar" onclick="eliminarProducto(${p.id})">Eliminar</button>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

// ========================
// GUARDAR PRODUCTO
// ========================
document.getElementById("form-producto").addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("prod_id").value;
  const name = document.getElementById("prod_name").value;
  const price = +document.getElementById("prod_price").value;
  const desc = document.getElementById("prod_desc").value;
  const category = document.getElementById("prod_category").value;
  const stock = +document.getElementById("prod_stock").value;
  const alertStock = +document.getElementById("prod_alert").value;
  const imgFile = document.getElementById("prod_image").files[0];

  const msg = document.getElementById("msgForm");
  msg.textContent = "";
  msg.className = "mensaje";

  let imageUrl = null;

  if (imgFile) {
    const fd = new FormData();
    fd.append("file", imgFile);

    const up = await fetch("/upload", { method: "POST", body: fd });
    const d = await up.json();
    imageUrl = d.url;
  }

  const body = {
    name,
    price,
    description: desc,
    category,
    stock,
    stock_alert: alertStock,
  };

  if (imageUrl) body.image = imageUrl;

  const method = id ? "PUT" : "POST";
  const url = id ? `/products/${id}` : "/products";

  const res = await fetch(url, {
    method,
    headers: {
      Authorization: "Bearer " + token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    msg.textContent = "Error guardando el producto";
    msg.className = "mensaje error";
    return;
  }

  msg.textContent = id ? "Producto actualizado" : "Producto creado";
  msg.className = "mensaje ok";

  resetForm();
  cargarProductos();
});

// ========================
// EDITAR PRODUCTO
// ========================
async function editarProducto(id) {
  const res = await fetch(`/products/${id}`);
  const p = await res.json();

  document.getElementById("prod_id").value = p.id;
  document.getElementById("prod_name").value = p.name;
  document.getElementById("prod_price").value = p.price;
  document.getElementById("prod_desc").value = p.description || "";
  document.getElementById("prod_stock").value = p.stock;
  document.getElementById("prod_alert").value = p.stock_alert;

  marcarCategoriaActiva(p.category || "");
}

// ========================
// ELIMINAR PRODUCTO
// ========================
async function eliminarProducto(id) {
  if (!confirm("¿Eliminar este producto?")) return;

  await fetch(`/products/${id}`, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token },
  });

  cargarProductos();
}

// ========================
// RESET FORM
// ========================
function resetForm() {
  document.getElementById("form-producto").reset();
  document.getElementById("prod_id").value = "";
  document.getElementById("prod_category").value = "";
  marcarCategoriaActiva("");
}

// ========================
// INICIO
// ========================
document.addEventListener("DOMContentLoaded", () => {
  cargarCategoriasDisponible();
  cargarProductos();
});

window.editarProducto = editarProducto;
window.eliminarProducto = eliminarProducto;
window.goBack = goBack;
window.logout = logout;
window.resetForm = resetForm;
